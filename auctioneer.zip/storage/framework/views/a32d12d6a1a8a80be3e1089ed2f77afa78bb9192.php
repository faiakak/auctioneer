

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-10 col-md-offset-1">
                <div class="panel panel-default">
                    <div class="panel-heading">List an item</div>

                    <div class="panel-body">
                        <form action="<?php echo e(route('item.store')); ?>" method="POST" class="form">
                            <?php echo e(method_field('POST')); ?>

                            <?php echo e(csrf_field()); ?>

                            <div class="form-group <?php echo e($errors->has('categories') ? 'has-error' : ''); ?>">
                                <label class="control-label" for="categories">Categories</label>
                                <select name="categories[]" id="categories" class="form-control" multiple>
                                    <?php foreach( $categories as $category ): ?>
                                        <option value="<?php echo e($category->id); ?>" <?php echo e(old('categories') == $category->slug ? 'selected' : ''); ?>><?php echo e($category->title); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group <?php echo e($errors->has('title') ? 'has-error':''); ?>">
                                <label class="control-label" for="title">Title</label>
                                <input id="title" name="title" class="form-control" type="text" placeholder="Title" value="<?php echo e(old('title')); ?>">
                                <?php if($errors->has('title')): ?>
                                    <p class="help-block"><?php echo e($errors->get('title')[0]); ?></p>
                                <?php endif; ?>
                            </div>
                            <div class="form-group <?php echo e($errors->has('description') ? 'has-error' : ''); ?>">
                                <label class="control-label" for="description">Description</label>
                                <textarea id="description" name="description" class="form-control" type="text" placeholder="Description"><?php echo e(old('description')); ?></textarea>
                                <?php if($errors->has('description')): ?>
                                    <p class="help-block"><?php echo e($errors->get('description')[0]); ?></p>
                                <?php endif; ?>
                            </div>
                            <div class="form-group <?php echo e($errors->has('price') ? 'has-error' : ''); ?>">
                                <label for="price">Price</label>
                                <input id="price" name="price" class="form-control" type="text" placeholder="Price" value="<?php echo e(old('price')); ?>">
                                <?php if($errors->has('price')): ?>
                                    <p class="help-block"><?php echo e($errors->get('price')[0]); ?></p>
                                <?php endif; ?>
                            </div>
                            <div class="form-group <?php echo e($errors->has('duration') ? 'has-error' : ''); ?>">
                                <label class="control-label" for="duration">Duration (days)</label>
                                <input id="duration" name="duration" class="form-control" type="number" placeholder="Duration (days)" value="<?php echo e(old('duration')); ?>" min="0" max="28">
                                <?php if($errors->has('duration')): ?>
                                    <p class="help-block"><?php echo e($errors->get('duration')[0]); ?></p>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <input name="listItem" class="form-control btn btn-primary" type="submit" value="List Item">
                            </div>
                        </form>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    $('select').select2();
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>